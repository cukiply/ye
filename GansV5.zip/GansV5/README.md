# Jarot

<img src="https://telegra.ph/file/696076406bf2516adb1fd.jpg" width="200" height="200"/>


# NOTE: DILARANG MENJUAL BELIKAN SCRIPT 

